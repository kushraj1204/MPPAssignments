package lesson3.labs.prob1;

/**
 * @author kush
 */
public class Job {
    private double salary;

    public double getSalary() {
        return salary;
    }
}
