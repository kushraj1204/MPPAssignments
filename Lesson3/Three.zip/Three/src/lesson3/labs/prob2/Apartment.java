package lesson3.labs.prob2;

/**
 * @author kush
 */
public class Apartment {
    private double rent;

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }
}
